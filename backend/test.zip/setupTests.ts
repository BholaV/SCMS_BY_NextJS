// backend/tests/setupTests.ts

// You can add global setup code here if needed
// For example, extending matchers with @testing-library/jest-dom
import '@testing-library/jest-dom';
